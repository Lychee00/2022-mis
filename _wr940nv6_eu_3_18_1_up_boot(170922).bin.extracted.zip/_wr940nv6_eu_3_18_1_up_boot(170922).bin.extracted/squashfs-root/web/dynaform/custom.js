var str_wps_name_long = "Wi-Fi Protected Setup";
var str_wps_name_short = "WPS";
var str_wps_name_5g_long = "Wi-Fi Protected Setup";
var str_wps_name_5g_short = "WPS";
var wlan_wds = 1;

var display_pin_settings = 1;
var our_web_site = "www.tp-link.com";
var display_upgrade_site = 1;

var wireless_ssid_prefix = "TP-Link";
var ssid_without_mac = 0;
var wlan_wds = 1;

var default_usrname = "admin";
var default_password = "admin";
var default_lan_ip = "192.168.0.1";

var default_host_ip = "192.168.0.23";
var default_target_ip = "192.168.1.23";

var default_dhcps_begin = "192.168.0.100";
var default_dhcps_end = "192.168.0.199";

var g_wantype =1;
<script language="javascript" src="../dynaform/emulator.js" type="text/javascript">
</script>	